package com.example.contactbook;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class AddContactActivity extends AppCompatActivity {

    EditText etName;
    EditText etPhone;
    EditText etEmail;
    EditText etWebsite;
    EditText etAddress;

    Button btnSave;
    Button btnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_contact);

        Toolbar toolbar = findViewById(R.id.toolbarAdd);

        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);
        etEmail = findViewById(R.id.etEmail);
        etWebsite = findViewById(R.id.etWebsite);
        etAddress = findViewById(R.id.etAddress);

        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);

        btnSave.setOnClickListener(v -> saveContact());

        btnCancel.setOnClickListener(v -> finish());
    }

    private void saveContact() {

        String name = etName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String website = etWebsite.getText().toString().trim();
        String address = etAddress.getText().toString().trim();

        // Name is required
        if (TextUtils.isEmpty(name)) {

            etName.setError("Name is required");
            etName.requestFocus();
            return;
        }

        // Phone is required
        if (TextUtils.isEmpty(phone)) {

            etPhone.setError("Phone is required");
            etPhone.requestFocus();
            return;
        }

        android.content.Intent result =
                new android.content.Intent();

        result.putExtra("name", name);
        result.putExtra("phone", phone);
        result.putExtra("email", email);
        result.putExtra("website", website);
        result.putExtra("address", address);

        setResult(RESULT_OK, result);

        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {

        finish();

        return true;
    }
}