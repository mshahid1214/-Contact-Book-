package com.example.contactbook;

public class Contact {

    String name;
    String phone;
    String email;
    String website;
    String address;

    public Contact(String name, String phone, String email,
                   String website, String address) {

        this.name = name;
        this.phone = phone;
        this.email = email;
        this.website = website;
        this.address = address;
    }
}