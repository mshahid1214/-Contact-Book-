package com.example.contactbook;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ContactDetailsFragment extends Fragment {

    String name;
    String phone;
    String email;
    String website;
    String address;

    public static ContactDetailsFragment newInstance(
            String name,
            String phone,
            String email,
            String website,
            String address) {

        ContactDetailsFragment fragment =
                new ContactDetailsFragment();

        Bundle bundle = new Bundle();

        bundle.putString("name", name);
        bundle.putString("phone", phone);
        bundle.putString("email", email);
        bundle.putString("website", website);
        bundle.putString("address", address);

        fragment.setArguments(bundle);

        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(
                R.layout.fragment_contact_details,
                container,
                false
        );

        if (getArguments() != null) {

            name = getArguments().getString("name");
            phone = getArguments().getString("phone");
            email = getArguments().getString("email");
            website = getArguments().getString("website");
            address = getArguments().getString("address");
        }

        TextView txtInitial =
                view.findViewById(R.id.txtInitial);

        TextView txtName =
                view.findViewById(R.id.txtName);

        TextView txtPhone =
                view.findViewById(R.id.txtPhone);

        TextView txtEmail =
                view.findViewById(R.id.txtEmail);

        TextView txtWebsite =
                view.findViewById(R.id.txtWebsite);

        TextView txtAddress =
                view.findViewById(R.id.txtAddress);

        Button btnCall =
                view.findViewById(R.id.btnCall);

        Button btnEmail =
                view.findViewById(R.id.btnEmail);

        Button btnWebsite =
                view.findViewById(R.id.btnWebsite);

        Button btnMap =
                view.findViewById(R.id.btnMap);

        Button btnShare =
                view.findViewById(R.id.btnShare);

        txtInitial.setText(
                name.substring(0, 1).toUpperCase()
        );

        txtName.setText(name);
        txtPhone.setText("Phone: " + phone);
        txtEmail.setText("Email: " + email);
        txtWebsite.setText("Website: " + website);
        txtAddress.setText("Address: " + address);

        // Explicitly request the phone dialer because we want to dial this number.
        btnCall.setOnClickListener(v -> {

            Intent intent = new Intent(
                    Intent.ACTION_DIAL,
                    Uri.parse("tel:" + phone)
            );

            openIntent(intent);
        });

        // Implicitly request an email application using the mailto URI.
        btnEmail.setOnClickListener(v -> {

            Intent intent = new Intent(
                    Intent.ACTION_SENDTO,
                    Uri.parse("mailto:" + email)
            );

            intent.putExtra(
                    Intent.EXTRA_SUBJECT,
                    "Contact from Contact Book"
            );

            openIntent(intent);
        });

        // Implicitly request any browser application that can open the website.
        btnWebsite.setOnClickListener(v -> {

            Intent intent = new Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse(website)
            );

            openIntent(intent);
        });

        // Implicitly request a map application to display the contact's address.
        btnMap.setOnClickListener(v -> {

            Uri mapUri = Uri.parse(
                    "geo:0,0?q=" + Uri.encode(address)
            );

            Intent intent = new Intent(
                    Intent.ACTION_VIEW,
                    mapUri
            );

            openIntent(intent);
        });

        // Implicitly request apps that can share text because the user can choose any app.
        btnShare.setOnClickListener(v -> {

            String contactInfo =
                    "Name: " + name +
                            "\nPhone: " + phone +
                            "\nEmail: " + email;

            Intent intent = new Intent(Intent.ACTION_SEND);

            intent.setType("text/plain");

            intent.putExtra(
                    Intent.EXTRA_TEXT,
                    contactInfo
            );

            Intent chooser = Intent.createChooser(
                    intent,
                    "Share Contact"
            );

            openIntent(chooser);
        });

        return view;
    }

    private void openIntent(Intent intent) {

        try {

            if (intent.resolveActivity(
                    requireActivity().getPackageManager()
            ) != null) {

                startActivity(intent);

            } else {

                Toast.makeText(
                        requireContext(),
                        "No app available for this action",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (ActivityNotFoundException e) {

            Toast.makeText(
                    requireContext(),
                    "No app available for this action",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}