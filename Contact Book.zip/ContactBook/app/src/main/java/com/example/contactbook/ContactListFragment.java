package com.example.contactbook;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ContactListFragment extends Fragment {

    LinearLayout contactContainer;
    Button btnAdd;

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(
                R.layout.fragment_contact_list,
                container,
                false
        );

        contactContainer =
                view.findViewById(R.id.contact_container);

        btnAdd =
                view.findViewById(R.id.btnAdd);

        MainActivity activity =
                (MainActivity) requireActivity();

        // Display all contacts
        for (Contact contact : activity.getContactList()) {

            addContactRow(contact);
        }

        btnAdd.setOnClickListener(v ->
                activity.openAddContact()
        );

        return view;
    }

    private void addContactRow(Contact contact) {

        LinearLayout row = new LinearLayout(requireContext());

        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(16, 10, 10, 10);

        TextView initial = new TextView(requireContext());

        initial.setText(
                contact.name.substring(0, 1).toUpperCase()
        );

        initial.setTextColor(Color.WHITE);
        initial.setTextSize(18);
        initial.setGravity(android.view.Gravity.CENTER);

        initial.setBackgroundResource(
                R.drawable.circle_background
        );

        LinearLayout.LayoutParams initialParams =
                new LinearLayout.LayoutParams(42, 42);

        row.addView(initial, initialParams);

        LinearLayout information =
                new LinearLayout(requireContext());

        information.setOrientation(LinearLayout.VERTICAL);

        TextView name =
                new TextView(requireContext());

        name.setText(contact.name);
        name.setTextSize(16);
        name.setTextColor(Color.DKGRAY);
        name.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView phone =
                new TextView(requireContext());

        phone.setText(contact.phone);
        phone.setTextSize(13);
        phone.setTextColor(Color.GRAY);

        information.addView(name);
        information.addView(phone);

        LinearLayout.LayoutParams infoParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                );

        infoParams.setMargins(12, 0, 0, 0);

        row.addView(information, infoParams);

        // Open Screen 2 when the contact is tapped
        row.setOnClickListener(v -> {

            MainActivity activity =
                    (MainActivity) requireActivity();

            activity.showContactDetails(contact);
        });

        contactContainer.addView(row);

        // Divider
        View divider = new View(requireContext());

        divider.setBackgroundColor(Color.LTGRAY);

        contactContainer.addView(
                divider,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        1
                )
        );
    }
}
