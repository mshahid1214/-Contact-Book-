package com.example.contactbook;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar;

    ArrayList<Contact> contactList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        // Four hard-coded sample contacts
        contactList.add(new Contact(
                "Sara Ahmed",
                "0300 1234567",
                "sara@example.com",
                "https://example.com",
                "Lahore, Pakistan"
        ));

        contactList.add(new Contact(
                "Usman Ali",
                "0301 7654321",
                "usman@example.com",
                "https://example.com",
                "Lahore, Pakistan"
        ));

        contactList.add(new Contact(
                "Hina Malik",
                "0322 1112233",
                "hina@example.com",
                "https://example.com",
                "Lahore, Pakistan"
        ));

        contactList.add(new Contact(
                "Bilal Raza",
                "0333 4445566",
                "bilal@example.com",
                "https://example.com",
                "Lahore, Pakistan"
        ));

        if (savedInstanceState == null) {
            showContactList();
        }
    }

    public void showContactList() {

        toolbar.setTitle("Contact Book");
        toolbar.setNavigationIcon(null);

        ContactListFragment fragment = new ContactListFragment();

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }

    public void showContactDetails(Contact contact) {

        toolbar.setTitle("Contact Details");
        toolbar.setNavigationIcon(
                androidx.appcompat.R.drawable.abc_ic_ab_back_material
        );

        ContactDetailsFragment fragment =
                ContactDetailsFragment.newInstance(
                        contact.name,
                        contact.phone,
                        contact.email,
                        contact.website,
                        contact.address
                );

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit();

        toolbar.setNavigationOnClickListener(v ->
                getSupportFragmentManager().popBackStack()
        );
    }

    public ArrayList<Contact> getContactList() {
        return contactList;
    }

    public void openAddContact() {

        Intent intent = new Intent(
                MainActivity.this,
                AddContactActivity.class
        );

        startActivityForResult(intent, 100);
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {

            String name = data.getStringExtra("name");
            String phone = data.getStringExtra("phone");
            String email = data.getStringExtra("email");
            String website = data.getStringExtra("website");
            String address = data.getStringExtra("address");

            Contact newContact = new Contact(
                    name,
                    phone,
                    email,
                    website,
                    address
            );

            contactList.add(newContact);

            showContactList();
        }
    }

    @Override
    public void onBackPressed() {

        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {

            getSupportFragmentManager().popBackStack();

        } else {

            super.onBackPressed();
        }
    }
}